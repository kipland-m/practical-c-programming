float square(s)
int s;
{
    return (s * s);
}
